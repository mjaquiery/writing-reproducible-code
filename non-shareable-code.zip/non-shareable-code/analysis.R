# Figure out the average MPG and Horsepower of cars by cylinder count.

library("tidyverse")

data <- read.csv("G:\\Documents\\University\\Programming\\R\\non-shareable-code\\mtcars.csv", row.names = 1)

data %>%
  tibble() %>%
  group_by(cyl) %>%
  summarise(
    n = n(),
    across(c(mpg, hp), mean, .names = "mean_{.col}")
    )

# Use stringr to generate a vector of TRUEs  [works in stringr < 1.5.0]
str_detect(letters, "")
